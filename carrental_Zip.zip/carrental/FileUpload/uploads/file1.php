<?php
$variable = "test`whoami`test";
system("echo ".$variable);
?>
